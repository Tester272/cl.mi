package dev.zanixio.client.compat;

import dev.zanixio.client.gfx.Painter;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Minecraft 26.1: GuiGraphics became GuiGraphicsExtractor, drawString became text. */
public final class GraphicsPainter implements Painter {
    private final GuiGraphicsExtractor g;
    private final Font font;

    public GraphicsPainter(GuiGraphicsExtractor g, Font font) {
        this.g = g;
        this.font = font;
    }

    @Override
    public void fill(int x1, int y1, int x2, int y2, int argb) {
        g.fill(x1, y1, x2, y2, argb);
    }

    @Override
    public void text(String s, int x, int y, int argb) {
        g.text(font, s, x, y, argb, true);
    }

    @Override
    public int width(String s) {
        return font.width(s);
    }

    @Override
    public int lineHeight() {
        return font.lineHeight;
    }
}
