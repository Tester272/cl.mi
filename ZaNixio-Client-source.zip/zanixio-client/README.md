# ZaNixio Client

Client-side Fabric utility client. Press **H** to open / close the menu (rebindable in Controls).
Left click a card = toggle module. Right click = open its settings. Mouse wheel scrolls.

## Two builds, one codebase

Minecraft 26.1+ is unobfuscated, needs Java 25 and a different Loom, and mods built for 1.21.x
do not load on it. So there are two small projects that share `common/`:

| Folder            | Minecraft | Java | Output jar                                   |
|-------------------|-----------|------|----------------------------------------------|
| `fabric-1.21.11/` | 1.21.11   | 21   | `build/libs/zanixio-client-1.0.0+mc1.21.11.jar` |
| `fabric-26.1/`    | 26.1.x    | 25   | `build/libs/zanixio-client-1.0.0+mc26.1.2.jar`  |

`common/` holds every module, the menu, the HUD and the config. Each `fabric-*/` folder only holds
the build files plus 3 small adapter classes (entrypoint, screen, painter) where the two
Minecraft versions differ.

## Build without installing anything (GitHub Actions)

`.github/workflows/build.yml` is already set up to compile both jars in the cloud on every push:

1. Create a new empty repo on github.com (from your phone or a browser is fine).
2. Upload the contents of this folder to it — either `git push`, or GitHub's web "Add file → Upload files"
   with everything unzipped, or drag the whole extracted folder into GitHub Desktop.
3. Open the repo's **Actions** tab. A run called "Build ZaNixio Client jars" starts automatically
   (or click **Run workflow** to start it by hand).
4. When it finishes (a few minutes), open the run and download the two files under **Artifacts**:
   `ZaNixio-Client-fabric-1.21.11` and `ZaNixio-Client-fabric-26.1`. Each is a zip containing one `.jar`.

That jar is the real thing — built against the actual Minecraft/Fabric dependencies, not a mockup.

## Build locally instead

Needs Gradle 9.4+ (or open the folder in IntelliJ IDEA) and the JDK listed above.

    cd fabric-1.21.11      # or fabric-26.1
    gradle build           # jar appears in build/libs/
    gradle runClient       # optional: launch a dev client

Drop the jar (no "-sources" jar) into `.minecraft/mods` together with Fabric Loader and Fabric API.
Exact newest dependency versions: https://fabricmc.net/develop (edit `gradle.properties`).

## Running it on PojavLauncher (Android)

PojavLauncher runs real Minecraft Java Edition, so it takes Fabric mods the same way desktop does:

1. In PojavLauncher, launch the target vanilla version once (1.21.11 or 26.1.2) so its folders exist,
   then close it.
2. Options → **Launch mod installer** → run the Fabric installer for that same Minecraft version
   (this creates the Fabric profile and the `.minecraft/mods` folder).
3. Also grab a matching **Fabric API** jar for that Minecraft version from Modrinth or CurseForge —
   ZaNixio needs it too. Put both that jar and the ZaNixio jar you built above into `.minecraft/mods`
   (enable "show hidden files" in your file manager to see `.minecraft` under Android/data or the
   folder PojavLauncher shows in its own file manager).
4. Launch the Fabric profile from PojavLauncher, not the vanilla one.

**Binding H on a touchscreen:** the mod listens for the physical "H" key, same as on desktop — there's
nothing phone-specific to change in the code. To press it with your thumb, open PojavLauncher's
**Custom Controls** editor, add a new button, and set its bound key to **H**. Tapping that button opens
and closes the ZaNixio menu; once the menu is open, normal touch taps work as mouse clicks on the cards,
sliders and toggles, since PojavLauncher maps touch to the mouse cursor inside any Minecraft screen.

## Modules

Combat: KillAura
Movement: AutoSprint, Flight, Speed, Step, Spider, AutoWalk, Sneak
Render: Fullbright, Zoom, ESP
Player: AutoRespawn, AntiAFK
HUD: Watermark, ModuleList, Coordinates, Info (FPS + blocks/second)

Settings and on/off state are saved to `config/zanixio.json`.

## Adding a module

Create a class in `common/.../module/impl/` that extends `Mod`, override `onEnable/onTick/onDisable`,
declare settings with `bool(...)` / `num(...)`, and register it in `ZaNixio.init()`.
It then shows up in the menu automatically.

## Notes

* Many servers ban or kick for Flight, Speed, KillAura, ESP etc. Use them in singleplayer or where allowed.
* Minecraft 26.2 renamed `Minecraft.setScreen` to `setScreenAndShow` - change that one call in `ZaNixioEntry`.
* Other 1.21.x versions (before 1.21.9 input events, before 1.21.6 HUD API) need their own adapter folder.
* Zoom changes the FOV option while active and restores it when turned off / leaving the world.
