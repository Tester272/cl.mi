package dev.zanixio.client.compat;

import dev.zanixio.client.gfx.Painter;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

/** Minecraft 1.21.11: GuiGraphics. */
public final class GraphicsPainter implements Painter {
    private final GuiGraphics g;
    private final Font font;

    public GraphicsPainter(GuiGraphics g, Font font) {
        this.g = g;
        this.font = font;
    }

    @Override
    public void fill(int x1, int y1, int x2, int y2, int argb) {
        g.fill(x1, y1, x2, y2, argb);
    }

    @Override
    public void text(String s, int x, int y, int argb) {
        g.drawString(font, s, x, y, argb, true);
    }

    @Override
    public int width(String s) {
        return font.width(s);
    }

    @Override
    public int lineHeight() {
        return font.lineHeight;
    }
}
