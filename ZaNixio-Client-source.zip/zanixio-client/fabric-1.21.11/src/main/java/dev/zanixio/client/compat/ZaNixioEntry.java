package dev.zanixio.client.compat;

import com.mojang.blaze3d.platform.InputConstants;
import dev.zanixio.client.ZaNixio;
import dev.zanixio.client.gui.HudCore;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

/** Minecraft 1.21.11 entrypoint. */
public final class ZaNixioEntry implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ZaNixio.init();

        KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath("zanixio", "main"));
        KeyMapping openGui = KeyBindingHelper.registerKeyBinding(
                new KeyMapping("key.zanixio.open_gui", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_H, category));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openGui.consumeClick()) {
                if (mc.screen == null && mc.player != null) mc.setScreen(new ClickGuiScreen());
            }
            ZaNixio.tick(mc);
        });

        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath("zanixio", "hud"),
                (graphics, delta) -> {
                    Minecraft mc = Minecraft.getInstance();
                    HudCore.render(new GraphicsPainter(graphics, mc.font), mc,
                            mc.getWindow().getGuiScaledWidth(), mc.getWindow().getGuiScaledHeight());
                });

        ClientLifecycleEvents.CLIENT_STOPPING.register(ZaNixio::shutdown);
    }
}
