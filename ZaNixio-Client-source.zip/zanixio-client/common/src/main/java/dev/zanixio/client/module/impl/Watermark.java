package dev.zanixio.client.module.impl;

import dev.zanixio.client.module.Category;
import dev.zanixio.client.module.Mod;

/** HUD element. Drawing lives in HudCore; this class only carries the on/off state. */
public final class Watermark extends Mod {
    public Watermark() {
        super("Watermark", "Shows the ZaNixio badge in the corner.", Category.HUD);
        setEnabled(true);
    }
}
