package dev.zanixio.client.gfx;

/**
 * Tiny drawing abstraction. The shared UI code only talks to this interface,
 * so the only version-specific rendering code is the small implementation
 * that lives in each fabric-* project (GuiGraphics vs GuiGraphicsExtractor).
 */
public interface Painter {
    void fill(int x1, int y1, int x2, int y2, int argb);

    void text(String s, int x, int y, int argb);

    int width(String s);

    int lineHeight();
}
