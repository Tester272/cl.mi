package dev.zanixio.client.module.impl;

import dev.zanixio.client.module.Category;
import dev.zanixio.client.module.Mod;
import net.minecraft.client.Minecraft;

public final class AutoWalk extends Mod {
    public AutoWalk() {
        super("AutoWalk", "Holds the forward key for you.", Category.MOVEMENT);
    }

    @Override
    public void onTick(Minecraft mc) {
        mc.options.keyUp.setDown(true);
    }

    @Override
    public void onDisable(Minecraft mc) {
        mc.options.keyUp.setDown(false);
    }
}
