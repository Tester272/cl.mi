package dev.zanixio.client.module.impl;

import dev.zanixio.client.module.Category;
import dev.zanixio.client.module.Mod;
import net.minecraft.client.Minecraft;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

/** Client-side night vision: lights up caves and the night without touching the server. */
public final class Fullbright extends Mod {
    private boolean weAdded;

    public Fullbright() {
        super("Fullbright", "See everything, even in the dark.", Category.RENDER);
    }

    @Override
    public void onEnable(Minecraft mc) {
        weAdded = mc.player != null && !mc.player.hasEffect(MobEffects.NIGHT_VISION);
    }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.player == null) return;
        MobEffectInstance cur = mc.player.getEffect(MobEffects.NIGHT_VISION);
        if (cur == null || cur.getDuration() < 400) {
            if (cur == null) weAdded = true;
            mc.player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 100000, 0, false, false, false));
        }
    }

    @Override
    public void onDisable(Minecraft mc) {
        if (mc.player != null && weAdded) mc.player.removeEffect(MobEffects.NIGHT_VISION);
        weAdded = false;
    }
}
