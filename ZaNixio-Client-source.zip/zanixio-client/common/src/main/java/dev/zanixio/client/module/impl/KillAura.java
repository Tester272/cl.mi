package dev.zanixio.client.module.impl;

import dev.zanixio.client.module.Category;
import dev.zanixio.client.module.Mod;
import dev.zanixio.client.module.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.player.Player;

import java.util.List;

public final class KillAura extends Mod {
    private final Setting range = num("Range", 3.0, 1.0, 6.0, 0.1);
    private final Setting monsters = bool("Monsters", true);
    private final Setting players = bool("Players", false);
    private final Setting animals = bool("Animals", false);

    public KillAura() {
        super("KillAura", "Attacks nearby targets when your weapon is charged.", Category.COMBAT);
    }

    private boolean wanted(Entity e) {
        if (e.getType() == EntityType.ARMOR_STAND) return false;
        if (e instanceof Player) return players.getBool();
        if (e.getType().getCategory() == MobCategory.MONSTER) return monsters.getBool();
        return animals.getBool();
    }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null || p.isDeadOrDying()) return;
        if (p.getAttackStrengthScale(0.5f) < 0.95f) return;

        double r = range.getNum();
        List<Entity> nearby = mc.level.getEntities(p, p.getBoundingBox().inflate(r),
                e -> e instanceof LivingEntity le && le.isAlive());
        Entity best = null;
        double bestDist = r * r;
        for (Entity e : nearby) {
            if (!wanted(e)) continue;
            double d = p.distanceToSqr(e);
            if (d <= bestDist) {
                bestDist = d;
                best = e;
            }
        }
        if (best != null) {
            mc.gameMode.attack(p, best);
            p.swing(InteractionHand.MAIN_HAND);
        }
    }
}
