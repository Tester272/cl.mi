package dev.zanixio.client.module.impl;

import dev.zanixio.client.module.Category;
import dev.zanixio.client.module.Mod;
import dev.zanixio.client.module.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

public final class AutoSprint extends Mod {
    private final Setting omni = bool("All directions", false);

    public AutoSprint() {
        super("AutoSprint", "Sprints for you while you move.", Category.MOVEMENT);
    }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null) return;
        boolean wantsMove = omni.getBool() ? MoveUtil.moving(mc.options) : mc.options.keyUp.isDown();
        if (wantsMove && !p.isShiftKeyDown() && !p.isUsingItem() && !p.horizontalCollision
                && p.getFoodData().getFoodLevel() > 6) {
            p.setSprinting(true);
        }
    }
}
