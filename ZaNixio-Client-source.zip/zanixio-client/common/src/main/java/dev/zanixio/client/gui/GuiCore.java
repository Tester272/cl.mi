package dev.zanixio.client.gui;

import dev.zanixio.client.ZaNixio;
import dev.zanixio.client.gfx.Colors;
import dev.zanixio.client.gfx.Painter;
import dev.zanixio.client.module.Category;
import dev.zanixio.client.module.Mod;
import dev.zanixio.client.module.Setting;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * The ZaNixio menu: a floating "dock" panel with a category rail on the left and
 * module cards on the right. Left click a card = toggle, right click = open its settings.
 * Purely drawn through {@link Painter}, so it is identical on every Minecraft version.
 */
public final class GuiCore {
    private static final int W_DEFAULT = 460;
    private static final int H_DEFAULT = 300;
    private static final int W_MIN = 260;
    private static final int H_MIN = 190;
    private static final int RAIL = 100;
    private static final int ROW = 30;
    private static final int SROW = 18;

    private static final class Hit {
        final int x1, y1, x2, y2;
        final Runnable left, right;
        final Setting slider;
        final int sx1, sx2;

        Hit(int x1, int y1, int x2, int y2, Runnable left, Runnable right, Setting slider, int sx1, int sx2) {
            this.x1 = x1;
            this.y1 = y1;
            this.x2 = x2;
            this.y2 = y2;
            this.left = left;
            this.right = right;
            this.slider = slider;
            this.sx1 = sx1;
            this.sx2 = sx2;
        }

        boolean contains(double x, double y) {
            return x >= x1 && x < x2 && y >= y1 && y < y2;
        }
    }

    private final List<Hit> hits = new ArrayList<>();
    private final Map<Mod, Float> toggleAnim = new HashMap<>();
    private final Set<Mod> expanded = new HashSet<>();
    private Category cat = Category.MOVEMENT;
    private float scroll;
    private float targetScroll;
    private float contentH;
    private long openedAt = System.nanoTime();
    private Setting dragging;
    private int dragX1;
    private int dragX2;
    private float fade = 1f;
    /** Panel size for the current frame; shrinks to fit small (phone) screens. Set at the top of render(). */
    private int W = W_DEFAULT;
    private int H = H_DEFAULT;

    public void onOpen() {
        openedAt = System.nanoTime();
    }

    public void onClose() {
        dragging = null;
        ZaNixio.save();
    }

    private int a(int color) {
        return Colors.scaleAlpha(color, fade);
    }

    private static boolean in(int mx, int my, int x1, int y1, int x2, int y2) {
        return mx >= x1 && mx < x2 && my >= y1 && my < y2;
    }

    // ------------------------------------------------------------------ render

    public void render(Painter p, int sw, int sh, int mx, int my) {
        hits.clear();
        float sec = (System.nanoTime() - openedAt) / 1_000_000_000f;
        float k = Math.min(1f, sec / 0.25f);
        fade = Math.max(0.08f, 1f - (1f - k) * (1f - k)); // never fully 0: vanilla treats alpha<4 text as opaque
        float time = System.nanoTime() / 1_000_000_000f;

        // Fit the panel to small (phone/PojavLauncher) screens instead of overflowing them.
        W = Math.max(W_MIN, Math.min(W_DEFAULT, sw - 16));
        H = Math.max(H_MIN, Math.min(H_DEFAULT, sh - 16));

        int x = (sw - W) / 2;
        int y = (sh - H) / 2 + Math.round((1f - fade) * 14f);

        // dim the world
        p.fill(0, 0, sw, sh, Colors.argb(Math.round(130 * fade), 4, 3, 12));

        // soft neon glow behind the panel
        int glow = Colors.brand(time * 0.15f);
        for (int i = 6; i >= 1; i--) {
            p.fill(x - i, y - i, x + W + i, y + H + i, a(Colors.withAlpha(glow, 8 + (6 - i) * 3)));
        }

        // panel + rail
        p.fill(x, y, x + W, y + H, a(0xF00A0A15));
        p.fill(x, y, x + RAIL, y + H, a(0xFF0D0D1B));
        p.fill(x + RAIL, y, x + RAIL + 1, y + H, a(0xFF1E1E3A));

        // animated top/bottom edge and corner brackets
        edge(p, x, y, x + W, y + 2, time, 0f);
        edge(p, x, y + H - 2, x + W, y + H, time, 0.5f);
        brackets(p, x, y, W, H, a(Colors.CYAN));

        drawRail(p, x, y, mx, my, time);
        drawContent(p, x, y, mx, my);
    }

    private void edge(Painter p, int x1, int y1, int x2, int y2, float time, float phase) {
        int w = x2 - x1;
        for (int i = 0; i < w; i += 2) {
            int c = Colors.brand(time * 0.2f + phase + i / (float) w * 0.8f);
            p.fill(x1 + i, y1, Math.min(x1 + i + 2, x2), y2, a(c));
        }
    }

    private void brackets(Painter p, int x, int y, int w, int h, int col) {
        int l = 10;
        p.fill(x - 3, y - 3, x + l, y - 2, col);
        p.fill(x - 3, y - 3, x - 2, y + l, col);
        p.fill(x + w - l, y - 3, x + w + 3, y - 2, col);
        p.fill(x + w + 2, y - 3, x + w + 3, y + l, col);
        p.fill(x - 3, y + h + 2, x + l, y + h + 3, col);
        p.fill(x - 3, y + h - l, x - 2, y + h + 3, col);
        p.fill(x + w - l, y + h + 2, x + w + 3, y + h + 3, col);
        p.fill(x + w + 2, y + h - l, x + w + 3, y + h + 3, col);
    }

    private void drawRail(Painter p, int x, int y, int mx, int my, float time) {
        // logo with a colour wave running through the letters
        String logo = "ZANIXIO";
        int lx = x + 12;
        for (int i = 0; i < logo.length(); i++) {
            String ch = logo.substring(i, i + 1);
            p.text(ch, lx, y + 14, a(Colors.brand(time * 0.25f + i * 0.09f)));
            lx += p.width(ch) + 1;
        }
        p.text("CLIENT  v" + ZaNixio.VERSION, x + 12, y + 26, a(0xFF6B6B8F));

        int cy = y + 48;
        for (Category c : Category.values()) {
            int x1 = x + 8;
            int x2 = x + RAIL - 8;
            int y1 = cy;
            int y2 = cy + 24;
            boolean sel = c == cat;
            boolean hov = in(mx, my, x1, y1, x2, y2);
            if (sel) {
                p.fill(x1, y1, x2, y2, a(Colors.withAlpha(c.color, 45)));
                p.fill(x1, y1, x1 + 3, y2, a(c.color));
            } else if (hov) {
                p.fill(x1, y1, x2, y2, a(0x22FFFFFF));
            }
            p.text(c.label, x1 + 10, y1 + 8, a(sel ? 0xFFFFFFFF : hov ? 0xFFD6D6F0 : 0xFF8A8AAE));

            int on = 0;
            for (Mod m : ZaNixio.MODS.in(c)) if (m.isEnabled()) on++;
            if (on > 0) {
                String s = String.valueOf(on);
                p.text(s, x2 - 6 - p.width(s), y1 + 8, a(Colors.withAlpha(c.color, 220)));
            }

            final Category target = c;
            hits.add(new Hit(x1, y1, x2, y2, () -> {
                cat = target;
                scroll = 0;
                targetScroll = 0;
            }, null, null, 0, 0));
            cy += 28;
        }
        p.text("[H] close", x + 12, y + H - 16, a(0xFF55557A));
    }

    private void drawContent(Painter p, int x, int y, int mx, int my) {
        int cx1 = x + RAIL + 14;
        int cx2 = x + W - 14;
        int top = y + 44;
        int bottom = y + H - 12;

        List<Mod> mods = ZaNixio.MODS.in(cat);
        p.text(cat.label.toUpperCase(Locale.ROOT), cx1, y + 14, a(cat.color));
        String count = mods.size() + " modules";
        p.text(count, cx2 - p.width(count), y + 14, a(0xFF6B6B8F));
        p.fill(cx1, y + 30, cx2, y + 31, a(Colors.withAlpha(cat.color, 90)));

        float viewH = bottom - top;
        float maxScroll = Math.max(0f, contentH - viewH);
        targetScroll = Math.max(0f, Math.min(maxScroll, targetScroll));
        scroll += (targetScroll - scroll) * 0.35f;

        int origin = top - Math.round(scroll);
        int ry = origin;
        for (Mod m : mods) ry = drawMod(p, m, cx1, cx2, ry, top, bottom, mx, my);
        contentH = ry - origin;
    }

    private int drawMod(Painter p, Mod m, int x1, int x2, int y, int top, int bottom, int mx, int my) {
        int h = ROW - 4;
        boolean visible = y >= top && y + h <= bottom;
        boolean on = m.isEnabled();
        float an = toggleAnim.getOrDefault(m, on ? 1f : 0f);
        an += ((on ? 1f : 0f) - an) * 0.3f;
        toggleAnim.put(m, an);
        int accent = m.category.color;

        if (visible) {
            boolean hov = in(mx, my, x1, y, x2, y + h);
            int base = 0xFF121227;
            int bg = Colors.lerp(base, Colors.lerp(base, accent, 0.22f), an);
            p.fill(x1, y, x2, y + h, a(bg));
            if (hov) p.fill(x1, y, x2, y + h, a(0x14FFFFFF));
            p.fill(x1, y, x1 + 3, y + h, a(Colors.lerp(0xFF2A2A48, accent, an)));
            p.text(m.name, x1 + 10, y + 4, a(Colors.lerp(0xFFB4B4D0, 0xFFFFFFFF, an)));
            p.text(m.description, x1 + 10, y + 15, a(0xFF6B6B8F));

            // toggle pill
            int px2 = x2 - 8;
            int px1 = px2 - 26;
            p.fill(px1, y + 7, px2, y + 19, a(Colors.lerp(0xFF2A2A48, accent, an)));
            int kx = px1 + 2 + Math.round(an * 14f);
            p.fill(kx, y + 9, kx + 8, y + 17, a(Colors.WHITE));

            final Mod target = m;
            hits.add(new Hit(x1, y, x2, y + h, target::toggle, () -> toggleExpanded(target), null, 0, 0));
            if (!m.getSettings().isEmpty()) {
                boolean open = expanded.contains(m);
                p.text(open ? "v" : ">", px1 - 14, y + 10, a(hov ? 0xFFFFFFFF : 0xFF8A8AAE));
                hits.add(new Hit(px1 - 20, y, px1 - 4, y + h, () -> toggleExpanded(target), () -> toggleExpanded(target), null, 0, 0));
            }
        }

        y += ROW;
        if (expanded.contains(m) && !m.getSettings().isEmpty()) {
            for (Setting s : m.getSettings()) y = drawSetting(p, s, x1, x2, y, top, bottom, accent);
            y += 4;
        }
        return y;
    }

    private void toggleExpanded(Mod m) {
        if (!expanded.remove(m)) expanded.add(m);
    }

    private int drawSetting(Painter p, Setting s, int x1, int x2, int y, int top, int bottom, int accent) {
        boolean visible = y >= top && y + SROW <= bottom;
        if (visible) {
            int sx1 = x1 + 10;
            int h = SROW - 2;
            p.fill(sx1, y, x2, y + h, a(0xFF0F0F22));
            p.fill(sx1, y, sx1 + 2, y + h, a(Colors.withAlpha(accent, 140)));
            int ty = y + (h - p.lineHeight()) / 2 + 1;
            p.text(s.name, sx1 + 8, ty, a(0xFFA0A0C0));

            if (s.isBool) {
                boolean v = s.getBool();
                int px2 = x2 - 8;
                int px1 = px2 - 20;
                p.fill(px1, y + 3, px2, y + 13, a(v ? accent : 0xFF2A2A48));
                int kx = v ? px2 - 9 : px1 + 1;
                p.fill(kx, y + 4, kx + 8, y + 12, a(Colors.WHITE));
                hits.add(new Hit(sx1, y, x2, y + h, () -> s.setBool(!s.getBool()), null, null, 0, 0));
            } else {
                int tw = 100;
                int t2 = x2 - 8;
                int t1 = t2 - tw;
                p.fill(t1, y + 7, t2, y + 9, a(0xFF2A2A48));
                double frac = (s.getNum() - s.min) / (s.max - s.min);
                int fx = t1 + (int) Math.round(frac * tw);
                p.fill(t1, y + 7, fx, y + 9, a(accent));
                p.fill(fx - 2, y + 4, fx + 2, y + 12, a(Colors.WHITE));
                String vs = format(s);
                p.text(vs, t1 - 8 - p.width(vs), ty, a(Colors.WHITE));
                hits.add(new Hit(t1 - 4, y, t2 + 4, y + h, null, null, s, t1, t2));
            }
        }
        return y + SROW;
    }

    private static String format(Setting s) {
        double v = s.getNum();
        if (s.step >= 1) return String.valueOf((int) Math.round(v));
        return String.format(Locale.ROOT, "%.2f", v);
    }

    // ------------------------------------------------------------------ input

    public boolean mouseClicked(double mx, double my, int button) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (!h.contains(mx, my)) continue;
            if (h.slider != null && button == 0) {
                dragging = h.slider;
                dragX1 = h.sx1;
                dragX2 = h.sx2;
                applyDrag(mx);
            } else if (button == 0 && h.left != null) {
                h.left.run();
            } else if (button == 1 && h.right != null) {
                h.right.run();
            }
            return true;
        }
        return false;
    }

    public boolean mouseDragged(double mx) {
        if (dragging == null) return false;
        applyDrag(mx);
        return true;
    }

    public boolean mouseReleased() {
        boolean was = dragging != null;
        dragging = null;
        return was;
    }

    public boolean mouseScrolled(double dy) {
        targetScroll -= (float) (dy * 22.0);
        return true;
    }

    private void applyDrag(double mx) {
        double t = (mx - dragX1) / (double) (dragX2 - dragX1);
        t = Math.max(0.0, Math.min(1.0, t));
        dragging.setNum(dragging.min + t * (dragging.max - dragging.min));
    }
}
