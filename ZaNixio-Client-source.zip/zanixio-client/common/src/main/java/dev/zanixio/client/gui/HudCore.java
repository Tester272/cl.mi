package dev.zanixio.client.gui;

import dev.zanixio.client.ZaNixio;
import dev.zanixio.client.gfx.Colors;
import dev.zanixio.client.gfx.Painter;
import dev.zanixio.client.module.Category;
import dev.zanixio.client.module.Mod;
import dev.zanixio.client.module.impl.Coordinates;
import dev.zanixio.client.module.impl.Info;
import dev.zanixio.client.module.impl.ModuleList;
import dev.zanixio.client.module.impl.Watermark;
import net.minecraft.client.Minecraft;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** In-game overlay: badge, active module list, coordinates and FPS/speed. */
public final class HudCore {
    private static long lastFpsTick = System.nanoTime();
    private static int frames;
    private static int fps;

    private HudCore() {}

    public static void render(Painter p, Minecraft mc, int sw, int sh) {
        if (mc.player == null) return;

        frames++;
        long now = System.nanoTime();
        if (now - lastFpsTick >= 1_000_000_000L) {
            fps = frames;
            frames = 0;
            lastFpsTick = now;
        }
        float time = now / 1_000_000_000f;

        int y = 4;
        if (ZaNixio.MODS.isOn(Watermark.class)) {
            String name = "ZaNixio";
            int w = 0;
            for (int i = 0; i < name.length(); i++) w += p.width(name.substring(i, i + 1)) + 1;
            p.fill(4, y, 4 + w + 12, y + p.lineHeight() + 4, 0xB0080810);
            p.fill(4, y, 6, y + p.lineHeight() + 4, Colors.brand(time * 0.25f));
            int x = 10;
            for (int i = 0; i < name.length(); i++) {
                String ch = name.substring(i, i + 1);
                p.text(ch, x, y + 2, Colors.brand(time * 0.25f + i * 0.09f));
                x += p.width(ch) + 1;
            }
            y += p.lineHeight() + 8;
        }

        if (ZaNixio.MODS.isOn(Coordinates.class)) {
            String s = String.format(Locale.ROOT, "XYZ  %.1f  %.1f  %.1f  [%s]",
                    mc.player.getX(), mc.player.getY(), mc.player.getZ(), mc.player.getDirection().getName());
            p.fill(4, y, 4 + p.width(s) + 8, y + p.lineHeight() + 3, 0x90080810);
            p.text(s, 8, y + 2, 0xFFE4E4F4);
            y += p.lineHeight() + 5;
        }

        if (ZaNixio.MODS.isOn(Info.class)) {
            Info info = ZaNixio.MODS.get(Info.class);
            String s = fps + " FPS   " + String.format(Locale.ROOT, "%.1f", info.bps()) + " b/s";
            p.fill(4, y, 4 + p.width(s) + 8, y + p.lineHeight() + 3, 0x90080810);
            p.text(s, 8, y + 2, 0xFFA0A0C0);
        }

        if (ZaNixio.MODS.isOn(ModuleList.class)) {
            List<Mod> active = new ArrayList<>();
            for (Mod m : ZaNixio.MODS.all()) {
                if (m.isEnabled() && m.category != Category.HUD) active.add(m);
            }
            active.sort((m1, m2) -> Integer.compare(p.width(m2.name), p.width(m1.name)));
            int ry = 4;
            int lh = p.lineHeight() + 2;
            for (int i = 0; i < active.size(); i++) {
                Mod m = active.get(i);
                int w = p.width(m.name);
                int x = sw - w - 8;
                int c = Colors.brand(time * 0.2f + i * 0.07f);
                p.fill(x - 3, ry, sw, ry + lh, 0x90080810);
                p.fill(sw - 2, ry, sw, ry + lh, c);
                p.text(m.name, x, ry + 2, c);
                ry += lh;
            }
        }
    }
}
