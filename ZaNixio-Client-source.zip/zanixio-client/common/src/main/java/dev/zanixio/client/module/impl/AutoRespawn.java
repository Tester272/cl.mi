package dev.zanixio.client.module.impl;

import dev.zanixio.client.module.Category;
import dev.zanixio.client.module.Mod;
import net.minecraft.client.Minecraft;

public final class AutoRespawn extends Mod {
    private int cooldown;

    public AutoRespawn() {
        super("AutoRespawn", "Respawns instantly when you die.", Category.PLAYER);
    }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.player == null) return;
        if (cooldown > 0) {
            cooldown--;
            return;
        }
        if (mc.player.isDeadOrDying()) {
            mc.player.respawn();
            cooldown = 10;
        }
    }
}
