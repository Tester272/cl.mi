package dev.zanixio.client.module.impl;

import dev.zanixio.client.module.Category;
import dev.zanixio.client.module.Mod;
import dev.zanixio.client.module.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;

public final class AntiAfk extends Mod {
    private final Setting seconds = num("Interval (s)", 20, 5, 120, 5);
    private int ticks;
    private int jumpTicks;
    private boolean flip;

    public AntiAfk() {
        super("AntiAFK", "Jumps, swings and turns now and then so you are not kicked.", Category.PLAYER);
    }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null) return;
        ticks++;
        if (ticks >= seconds.getInt() * 20) {
            ticks = 0;
            flip = !flip;
            p.swing(InteractionHand.MAIN_HAND);
            p.setYRot(p.getYRot() + (flip ? 20f : -20f));
            mc.options.keyJump.setDown(true);
            jumpTicks = 3;
        }
        if (jumpTicks > 0 && --jumpTicks == 0) mc.options.keyJump.setDown(false);
    }

    @Override
    public void onDisable(Minecraft mc) {
        mc.options.keyJump.setDown(false);
        jumpTicks = 0;
        ticks = 0;
    }
}
