package dev.zanixio.client.module.impl;

import dev.zanixio.client.module.Category;
import dev.zanixio.client.module.Mod;

/** HUD element. Drawing lives in HudCore; this class only carries the on/off state. */
public final class ModuleList extends Mod {
    public ModuleList() {
        super("ModuleList", "Lists your active modules, top right.", Category.HUD);
        setEnabled(true);
    }
}
