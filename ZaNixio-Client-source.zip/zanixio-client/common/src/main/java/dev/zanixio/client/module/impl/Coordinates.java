package dev.zanixio.client.module.impl;

import dev.zanixio.client.module.Category;
import dev.zanixio.client.module.Mod;

/** HUD element. Drawing lives in HudCore; this class only carries the on/off state. */
public final class Coordinates extends Mod {
    public Coordinates() {
        super("Coordinates", "Shows your XYZ and facing direction.", Category.HUD);
        setEnabled(true);
    }
}
