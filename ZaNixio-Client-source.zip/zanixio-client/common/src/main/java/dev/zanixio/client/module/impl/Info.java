package dev.zanixio.client.module.impl;

import dev.zanixio.client.module.Category;
import dev.zanixio.client.module.Mod;
import net.minecraft.client.Minecraft;

/** HUD element: FPS and speed in blocks per second (speed is measured here each tick). */
public final class Info extends Mod {
    private double lastX;
    private double lastZ;
    private boolean have;
    private volatile double bps;

    public Info() {
        super("Info", "Shows FPS and your speed in blocks per second.", Category.HUD);
        setEnabled(true);
    }

    public double bps() {
        return bps;
    }

    @Override
    public void onEnable(Minecraft mc) {
        have = false;
    }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.player == null) return;
        double x = mc.player.getX();
        double z = mc.player.getZ();
        if (have) bps = Math.sqrt((x - lastX) * (x - lastX) + (z - lastZ) * (z - lastZ)) * 20.0;
        lastX = x;
        lastZ = z;
        have = true;
    }
}
