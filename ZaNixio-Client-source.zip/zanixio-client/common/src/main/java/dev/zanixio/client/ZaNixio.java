package dev.zanixio.client;

import dev.zanixio.client.config.ZaNixioConfig;
import dev.zanixio.client.module.ModManager;
import dev.zanixio.client.module.impl.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;

public final class ZaNixio {
    public static final String NAME = "ZaNixio Client";
    public static final String VERSION = "1.0.0";
    public static final ModManager MODS = new ModManager();

    private static ZaNixioConfig config;

    private ZaNixio() {}

    public static void init() {
        // Combat
        MODS.add(new KillAura());
        // Movement
        MODS.add(new AutoSprint());
        MODS.add(new Flight());
        MODS.add(new Speed());
        MODS.add(new Step());
        MODS.add(new Spider());
        MODS.add(new AutoWalk());
        MODS.add(new Sneak());
        // Render
        MODS.add(new Fullbright());
        MODS.add(new Zoom());
        MODS.add(new Esp());
        // Player
        MODS.add(new AutoRespawn());
        MODS.add(new AntiAfk());
        // HUD
        MODS.add(new Watermark());
        MODS.add(new ModuleList());
        MODS.add(new Coordinates());
        MODS.add(new Info());

        config = new ZaNixioConfig(FabricLoader.getInstance().getConfigDir().resolve("zanixio.json"));
        config.load(MODS);
    }

    public static void tick(Minecraft mc) {
        MODS.tick(mc);
    }

    public static void save() {
        if (config != null) config.save(MODS);
    }

    public static void shutdown(Minecraft mc) {
        MODS.stopAll(mc);
        save();
    }
}
