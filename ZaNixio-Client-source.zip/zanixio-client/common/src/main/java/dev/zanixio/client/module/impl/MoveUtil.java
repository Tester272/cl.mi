package dev.zanixio.client.module.impl;

import net.minecraft.client.Options;

final class MoveUtil {
    private MoveUtil() {}

    static boolean moving(Options o) {
        return o.keyUp.isDown() || o.keyDown.isDown() || o.keyLeft.isDown() || o.keyRight.isDown();
    }

    /** Unit vector {x, z} for the current WASD input relative to the given yaw, or {0, 0}. */
    static double[] direction(Options o, float yawDeg) {
        double f = (o.keyUp.isDown() ? 1 : 0) - (o.keyDown.isDown() ? 1 : 0);
        double s = (o.keyLeft.isDown() ? 1 : 0) - (o.keyRight.isDown() ? 1 : 0);
        double yaw = Math.toRadians(yawDeg);
        double sin = Math.sin(yaw);
        double cos = Math.cos(yaw);
        double x = -sin * f + cos * s;
        double z = cos * f + sin * s;
        double len = Math.sqrt(x * x + z * z);
        if (len < 1.0E-4) return new double[]{0, 0};
        return new double[]{x / len, z / len};
    }
}
