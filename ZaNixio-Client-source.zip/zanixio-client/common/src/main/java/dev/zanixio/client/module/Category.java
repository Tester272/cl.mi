package dev.zanixio.client.module;

public enum Category {
    COMBAT("Combat", 0xFFFB7185),
    MOVEMENT("Movement", 0xFF34D399),
    RENDER("Render", 0xFF22D3EE),
    PLAYER("Player", 0xFFFBBF24),
    HUD("HUD", 0xFFA78BFA);

    public final String label;
    public final int color;

    Category(String label, int color) {
        this.label = label;
        this.color = color;
    }
}
