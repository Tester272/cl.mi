package dev.zanixio.client.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.zanixio.client.module.Mod;
import dev.zanixio.client.module.ModManager;
import dev.zanixio.client.module.Setting;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

public final class ZaNixioConfig {
    private static final Logger LOG = LoggerFactory.getLogger("ZaNixio");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private final Path file;

    public ZaNixioConfig(Path file) {
        this.file = file;
    }

    public void load(ModManager mods) {
        if (!Files.exists(file)) return;
        try (Reader r = Files.newBufferedReader(file)) {
            JsonObject root = JsonParser.parseReader(r).getAsJsonObject();
            for (Mod m : mods.all()) {
                JsonObject o = root.getAsJsonObject(m.name);
                if (o == null) continue;
                if (o.has("enabled")) m.setEnabled(o.get("enabled").getAsBoolean());
                for (Setting s : m.getSettings()) {
                    if (o.has(s.name)) s.set(o.get(s.name).getAsDouble());
                }
            }
        } catch (Exception e) {
            LOG.warn("Could not read {}", file, e);
        }
    }

    public void save(ModManager mods) {
        try {
            JsonObject root = new JsonObject();
            for (Mod m : mods.all()) {
                JsonObject o = new JsonObject();
                o.addProperty("enabled", m.isEnabled());
                for (Setting s : m.getSettings()) o.addProperty(s.name, s.raw());
                root.add(m.name, o);
            }
            Files.createDirectories(file.getParent());
            try (Writer w = Files.newBufferedWriter(file)) {
                GSON.toJson(root, w);
            }
        } catch (Exception e) {
            LOG.warn("Could not write {}", file, e);
        }
    }
}
