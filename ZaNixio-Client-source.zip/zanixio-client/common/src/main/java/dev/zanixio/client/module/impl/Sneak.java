package dev.zanixio.client.module.impl;

import dev.zanixio.client.module.Category;
import dev.zanixio.client.module.Mod;
import net.minecraft.client.Minecraft;

public final class Sneak extends Mod {
    public Sneak() {
        super("Sneak", "Holds the sneak key for you.", Category.MOVEMENT);
    }

    @Override
    public void onTick(Minecraft mc) {
        mc.options.keyShift.setDown(true);
    }

    @Override
    public void onDisable(Minecraft mc) {
        mc.options.keyShift.setDown(false);
    }
}
