package dev.zanixio.client.module;

import net.minecraft.client.Minecraft;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public abstract class Mod {
    public final String name;
    public final String description;
    public final Category category;

    private final List<Setting> settings = new ArrayList<>();
    private boolean enabled;
    /** Managed by ModManager: true once onEnable() has run in the current world. */
    boolean started;

    protected Mod(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    protected Setting bool(String name, boolean def) {
        Setting s = Setting.bool(name, def);
        settings.add(s);
        return s;
    }

    protected Setting num(String name, double def, double min, double max, double step) {
        Setting s = Setting.num(name, def, min, max, step);
        settings.add(s);
        return s;
    }

    public List<Setting> getSettings() {
        return Collections.unmodifiableList(settings);
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public void toggle() {
        this.enabled = !this.enabled;
    }

    /** Called once when the module turns on while a world is loaded. */
    public void onEnable(Minecraft mc) {}

    /** Called when it turns off, or when you leave the world / quit. mc.player may be null here. */
    public void onDisable(Minecraft mc) {}

    /** Called every client tick while enabled and in a world. */
    public void onTick(Minecraft mc) {}
}
