package dev.zanixio.client.module.impl;

import dev.zanixio.client.module.Category;
import dev.zanixio.client.module.Mod;
import dev.zanixio.client.module.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

public final class Flight extends Mod {
    private final Setting speed = num("Speed", 0.6, 0.1, 3.0, 0.1);
    private final Setting vertical = num("Vertical", 0.4, 0.1, 2.0, 0.1);
    private final Setting antiKick = bool("Anti kick", true);
    private int ticks;

    public Flight() {
        super("Flight", "Fly like in creative. Space up, Shift down.", Category.MOVEMENT);
    }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null) return;
        ticks++;
        double[] d = MoveUtil.direction(mc.options, p.getYRot());
        double dy = mc.options.keyJump.isDown() ? vertical.getNum()
                : mc.options.keyShift.isDown() ? -vertical.getNum() : 0;
        if (antiKick.getBool() && dy == 0 && ticks % 20 == 0) dy = -0.04;
        p.setDeltaMovement(d[0] * speed.getNum(), dy, d[1] * speed.getNum());
    }
}
