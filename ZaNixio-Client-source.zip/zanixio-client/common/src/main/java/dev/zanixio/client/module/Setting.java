package dev.zanixio.client.module;

/** One setting: either an on/off toggle or a number with a min/max/step. */
public final class Setting {
    public final String name;
    public final boolean isBool;
    public final double min;
    public final double max;
    public final double step;
    private double value;

    private Setting(String name, boolean isBool, double def, double min, double max, double step) {
        this.name = name;
        this.isBool = isBool;
        this.min = min;
        this.max = max;
        this.step = step;
        this.value = def;
    }

    public static Setting bool(String name, boolean def) {
        return new Setting(name, true, def ? 1 : 0, 0, 1, 1);
    }

    public static Setting num(String name, double def, double min, double max, double step) {
        Setting s = new Setting(name, false, def, min, max, step);
        s.setNum(def);
        return s;
    }

    public boolean getBool() {
        return value > 0.5;
    }

    public double getNum() {
        return value;
    }

    public int getInt() {
        return (int) Math.round(value);
    }

    public double raw() {
        return value;
    }

    public void setBool(boolean b) {
        value = b ? 1 : 0;
    }

    public void setNum(double v) {
        v = Math.max(min, Math.min(max, v));
        if (step > 0) v = Math.round((v - min) / step) * step + min;
        value = Math.round(v * 1000.0) / 1000.0;
    }

    /** Used by the config loader. */
    public void set(double v) {
        if (isBool) setBool(v > 0.5);
        else setNum(v);
    }
}
