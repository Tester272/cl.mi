package dev.zanixio.client.gfx;

public final class Colors {
    public static final int VIOLET = 0xFF8B5CF6;
    public static final int CYAN = 0xFF22D3EE;
    public static final int WHITE = 0xFFFFFFFF;

    private Colors() {}

    public static int argb(int a, int r, int g, int b) {
        return (a & 255) << 24 | (r & 255) << 16 | (g & 255) << 8 | (b & 255);
    }

    public static int alpha(int c) {
        return c >>> 24;
    }

    public static int withAlpha(int c, int a) {
        return (Math.max(0, Math.min(255, a)) << 24) | (c & 0xFFFFFF);
    }

    public static int scaleAlpha(int c, float f) {
        return withAlpha(c, Math.round(alpha(c) * f));
    }

    public static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aa = Math.round(alpha(a) + (alpha(b) - alpha(a)) * t);
        int ar = Math.round(((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int ag = Math.round(((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int ab = Math.round((a & 255) + ((b & 255) - (a & 255)) * t);
        return argb(aa, ar, ag, ab);
    }

    /** Violet <-> cyan ping-pong gradient. t is any float; it wraps every 1.0. */
    public static int brand(float t) {
        t = t - (float) Math.floor(t);
        float k = t < 0.5f ? t * 2f : (1f - t) * 2f;
        return lerp(VIOLET, CYAN, k);
    }
}
