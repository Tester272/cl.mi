package dev.zanixio.client.module.impl;

import dev.zanixio.client.module.Category;
import dev.zanixio.client.module.Mod;
import dev.zanixio.client.module.Setting;
import net.minecraft.client.Minecraft;

public final class Zoom extends Mod {
    private final Setting fov = num("FOV", 30, 30, 90, 1);
    private int previous = -1;

    public Zoom() {
        super("Zoom", "Narrows your field of view for a spyglass effect.", Category.RENDER);
    }

    @Override
    public void onEnable(Minecraft mc) {
        previous = mc.options.fov().get();
    }

    @Override
    public void onTick(Minecraft mc) {
        int target = fov.getInt();
        if (mc.options.fov().get() != target) mc.options.fov().set(target);
    }

    @Override
    public void onDisable(Minecraft mc) {
        if (previous > 0) mc.options.fov().set(previous);
        previous = -1;
    }
}
