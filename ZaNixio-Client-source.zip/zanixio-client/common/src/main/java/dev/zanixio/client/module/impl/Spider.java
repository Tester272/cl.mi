package dev.zanixio.client.module.impl;

import dev.zanixio.client.module.Category;
import dev.zanixio.client.module.Mod;
import dev.zanixio.client.module.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;

public final class Spider extends Mod {
    private final Setting speed = num("Climb speed", 0.2, 0.1, 0.6, 0.05);

    public Spider() {
        super("Spider", "Climb walls by pushing into them.", Category.MOVEMENT);
    }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null) return;
        if (p.horizontalCollision && (mc.options.keyUp.isDown() || mc.options.keyJump.isDown())) {
            Vec3 v = p.getDeltaMovement();
            p.setDeltaMovement(v.x, speed.getNum(), v.z);
        }
    }
}
