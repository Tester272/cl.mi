package dev.zanixio.client.module;

import net.minecraft.client.Minecraft;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ModManager {
    private static final Logger LOG = LoggerFactory.getLogger("ZaNixio");
    private final List<Mod> mods = new ArrayList<>();

    public void add(Mod m) {
        mods.add(m);
    }

    public List<Mod> all() {
        return Collections.unmodifiableList(mods);
    }

    public List<Mod> in(Category c) {
        List<Mod> out = new ArrayList<>();
        for (Mod m : mods) if (m.category == c) out.add(m);
        return out;
    }

    public <T extends Mod> T get(Class<T> type) {
        for (Mod m : mods) if (type.isInstance(m)) return type.cast(m);
        return null;
    }

    public boolean isOn(Class<? extends Mod> type) {
        Mod m = get(type);
        return m != null && m.isEnabled();
    }

    public void tick(Minecraft mc) {
        boolean inWorld = mc.player != null && mc.level != null;
        for (Mod m : mods) {
            try {
                if (!inWorld) {
                    if (m.started) {
                        m.started = false;
                        m.onDisable(mc);
                    }
                    continue;
                }
                if (m.isEnabled() && !m.started) {
                    m.started = true;
                    m.onEnable(mc);
                } else if (!m.isEnabled() && m.started) {
                    m.started = false;
                    m.onDisable(mc);
                }
                if (m.isEnabled()) m.onTick(mc);
            } catch (Throwable t) {
                LOG.error("Module {} crashed and was disabled", m.name, t);
                m.setEnabled(false);
                m.started = false;
            }
        }
    }

    /** Runs every active module's onDisable so temporary changes (FOV, effects...) are undone. */
    public void stopAll(Minecraft mc) {
        for (Mod m : mods) {
            if (!m.started) continue;
            m.started = false;
            try {
                m.onDisable(mc);
            } catch (Throwable t) {
                LOG.warn("Module {} failed to stop cleanly", m.name, t);
            }
        }
    }
}
