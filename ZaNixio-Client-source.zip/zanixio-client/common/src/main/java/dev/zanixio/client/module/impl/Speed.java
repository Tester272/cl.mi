package dev.zanixio.client.module.impl;

import dev.zanixio.client.module.Category;
import dev.zanixio.client.module.Mod;
import dev.zanixio.client.module.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;

public final class Speed extends Mod {
    private final Setting speed = num("Speed", 0.32, 0.1, 1.5, 0.02);

    public Speed() {
        super("Speed", "Move faster on the ground and in the air.", Category.MOVEMENT);
    }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || !MoveUtil.moving(mc.options)) return;
        double[] d = MoveUtil.direction(mc.options, p.getYRot());
        Vec3 v = p.getDeltaMovement();
        p.setDeltaMovement(d[0] * speed.getNum(), v.y, d[1] * speed.getNum());
    }
}
