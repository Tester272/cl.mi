package dev.zanixio.client.module.impl;

import dev.zanixio.client.module.Category;
import dev.zanixio.client.module.Mod;
import dev.zanixio.client.module.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;

public final class Step extends Mod {
    private static final double VANILLA = 0.6;
    private final Setting height = num("Height", 1.5, 1.0, 5.0, 0.5);

    public Step() {
        super("Step", "Walk up blocks without jumping.", Category.MOVEMENT);
    }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.player == null) return;
        AttributeInstance a = mc.player.getAttribute(Attributes.STEP_HEIGHT);
        if (a != null && a.getBaseValue() != height.getNum()) a.setBaseValue(height.getNum());
    }

    @Override
    public void onDisable(Minecraft mc) {
        if (mc.player == null) return;
        AttributeInstance a = mc.player.getAttribute(Attributes.STEP_HEIGHT);
        if (a != null) a.setBaseValue(VANILLA);
    }
}
