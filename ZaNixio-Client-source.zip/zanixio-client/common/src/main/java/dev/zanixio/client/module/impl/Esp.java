package dev.zanixio.client.module.impl;

import dev.zanixio.client.module.Category;
import dev.zanixio.client.module.Mod;
import dev.zanixio.client.module.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.player.Player;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Outlines entities through walls using the vanilla glowing effect (client-side only). */
public final class Esp extends Mod {
    private final Setting range = num("Range", 64, 8, 128, 4);
    private final Setting players = bool("Players", true);
    private final Setting monsters = bool("Monsters", true);
    private final Setting animals = bool("Animals", false);
    private final Set<Entity> lit = new HashSet<>();

    public Esp() {
        super("ESP", "Outline players and mobs through walls.", Category.RENDER);
    }

    private boolean wanted(Entity e) {
        if (e == null || e.getType() == EntityType.ARMOR_STAND) return false;
        if (e instanceof Player) return players.getBool();
        if (e.getType().getCategory() == MobCategory.MONSTER) return monsters.getBool();
        return animals.getBool();
    }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.player == null || mc.level == null) return;
        double r = range.getNum();
        List<Entity> nearby = mc.level.getEntities(mc.player, mc.player.getBoundingBox().inflate(r),
                e -> e instanceof LivingEntity);
        Set<Entity> now = new HashSet<>();
        for (Entity e : nearby) {
            if (!wanted(e) || mc.player.distanceToSqr(e) > r * r) continue;
            e.setGlowingTag(true);
            now.add(e);
        }
        for (Entity old : lit) if (!now.contains(old)) old.setGlowingTag(false);
        lit.clear();
        lit.addAll(now);
    }

    @Override
    public void onDisable(Minecraft mc) {
        for (Entity e : lit) e.setGlowingTag(false);
        lit.clear();
    }
}
